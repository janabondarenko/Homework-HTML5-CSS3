
$('.reviews_ul').bxSlider({
    mode:  'fade',
    controls:  false ,
    
});